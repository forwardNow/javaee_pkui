2017/04/02

    1. 将图片转为base64编码

    2. 注释掉 border-radius 和 渐变

    3. // FIX 引入样式文件

    4. // FIX 添加 spell

    5. // FIX 修改option结果

    6. // FIX 修改搜索的属性

    7. // FIX 取消容器的宽度由计算select的宽度

    8. // FIX 添加字典支持

    9. // FIX 标志已注册

    10. // FIX 将 容器 放在 select的前面，避免错误提示位置错误。