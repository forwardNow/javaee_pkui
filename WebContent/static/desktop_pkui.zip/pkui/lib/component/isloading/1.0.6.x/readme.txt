2017/03/21

    1. // FIX 当在元素内显示loading时，使用append()添加_loader

    2. // FIX 修改 defaults

2017/04/06

    1. // FIX 去掉无用的功能

    2. // FIX 扩展 insideButton，按钮loading状态