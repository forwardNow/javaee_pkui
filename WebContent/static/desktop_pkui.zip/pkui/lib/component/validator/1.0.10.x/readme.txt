2017/03/22

    1. 将小图标以 base64 的方式置入css文件

    2. 兼容 CMD 模块

    3. // FIX 手动添加zh-CN国际化

    4. // FIX 取消插件自身的自动初始化

    5. // FIX 标志已被初始化

    x. // FIX 注册到PKUI

    6. // FIX 设置默认主题

    7. // FIX 更改实时验证

    8. // FIX 扩展参数：标志验证通过，准备提交表单，发送一个 ajaxSubmit.pkui.validator 的事件


2017/03/24

    1. // FIX 当 pos = "top" 时，让其显示右边

2017/04/04

    1. // FIX 修改 dataFilter

