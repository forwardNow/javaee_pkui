2017/03/17

    1. 修改样式

    2. // FIX 允许在全局环境查找 formatter

2017/03/18

    1. // FIX 初始化完毕，则添加HTML属性 isrendered="true"

    2. // FIX 将该插件挂载到 PKUI

2017/03/19

    1. // FIX 列宽可拖拽调整

    2. // FIX 字典翻译

2017/03/20

    1. // FIX 修复当 options 为 null时，options.rowCount 报错的情况

2017/03/22

    1. // FIX 给cell添加title

    2. // FIX 给cell包裹<p class="pkui-grid-cell">

2017/03/25

    1. //FIX 给checkbox的cell设置width=20px，title="";

    2. // FIX 当数据获取失败时的提示

    3. // FIX options.$element 指向<table>

    4. // FIX 扩展方法，获取被选中的行对应的数据

    5. // FIX 事件处理

2017/03/27

    1. // FIX loading时，保持表格大小

    2. // FIX noresult时，保持表格大小

    3. 修复当resize时，给td th设置padding导致的问题

    4. // FIX: 修改 remove方法

2017/04/01

    1. 将 checkbox 的宽度设置为 32px

    2. 添加调整列宽的标志

2017/04/06

    1. // FIX 修复当rowId为数字时，字符串和数字相严格比较出错的问题。

2017/04/28

    1. // FIX 修复 数字 与 数字字符串 的比较问题

        将"==="改为"=="