
2017/02/18

    1. 添加 AMD、CommonJS、CMD 支持
    2. 删除全局变量Swiper

2017/02/20

    1. 解决某些元素不可拖动，通过扩展一个参数 releaseElementsClass


2017/02/27

    1. // FIX 扩展参数 loopWithoutDuplicate：循环，但不在wrapper前后生成若干个slides；loop=true时设置
