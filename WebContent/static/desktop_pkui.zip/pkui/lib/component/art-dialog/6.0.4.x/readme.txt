2017/02/26

    1. // FIX 更改CSS类名：ui-dialog-* => pkui-dialog

    2. // FIX 禁止JS载入样式表

    3. // FIX 标题设置 jquery.text( title ) => jquery.text( html )

    4. // FIX 扩展一个 参数 pku_isNotCenter：reset() 和 show() 时，不居中；
       // 如果想居中则调用 __center() 实例方法


    5. // FIX 添加 seajs 支持


2017/02/27

    1. // FIX 添加 pkuiOptions 参数

    2. 将 参数pku_isNotCenter 更为为 isNotCenter，并置于 pkuiOptions

2017/03/16

    1. // FIX 关闭拖拽支持

2017/04/28

    1. // FIX 扩展参数"cancelOnPressEsc":当点击Esc是是否关闭对话框

2017/06/23

    1. // FIX 指定popup的容器的CSS选择器（默认为body）

