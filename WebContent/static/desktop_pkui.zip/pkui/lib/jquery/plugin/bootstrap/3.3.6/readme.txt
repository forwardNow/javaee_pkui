2017/04/07

    1. 将 tooltip.js 改造为 CMD 模块

    2. 将 $.fn.tooltip 改为 $.fn.bsTooltip

    3. FIX: 修复当 $element 被动态删除后，tooltip 还存在的情况

2017/04/26

    1. 将 tab.js 改造为 CMD 模块