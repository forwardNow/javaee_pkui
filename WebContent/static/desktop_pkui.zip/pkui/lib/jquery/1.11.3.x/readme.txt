1.11.3 版本的jQuery，只支持 CommonJS 和 ADM 规范；
此次修改让其支持 CMD规范。