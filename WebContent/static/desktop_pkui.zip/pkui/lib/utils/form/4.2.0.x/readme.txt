2017/03/22

    1. 兼容CMD

    2. // FIX 注册到 PKUI

    3. // FIX 监听 "ajaxSubmit.pkui.validator"